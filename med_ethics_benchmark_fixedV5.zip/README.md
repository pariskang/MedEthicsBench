# MedEthicsPsychBench v3 — Frontier-Hard Medical Ethics Benchmark

这是在 v2 基础上的 **hard benchmark 强化版**。目标不是“再多出一些题”，而是让题目和评分都更像真正能拉开前沿模型差距的 benchmark。

## 这次强化了什么

### 1. 更大的材料池
默认检索规模升级为：
- `global_theory_per_topic = 5`
- `country_theory_per_topic = 3`
- `cases_per_country_topic = 4`

这样单题不再只依赖极少数来源，更容易构造成：
- 实体伦理判断
- 程序义务
- 机构角色
- 后续事实更新

并存的复杂题。

### 2. 出题 prompt 从“高难作文题”升级为“frontier-hard benchmark 题”
现在题目必须尽量满足：
- 多步推理，而不是抽象原则复述
- 至少一个 realistic trap
- 区分 legal permissibility / institutional procedure / all-things-considered ethical justification
- 单国题和对比题必须有法域锚点
- 必须有可严格判分的 rubric
- 必须鼓励处理强反方论证

### 3. 生成后做严格结构校验
生成出的题如果出现这些问题会直接被淘汰：
- `stem` 过短
- `reference_answer` 过短
- `key_points` 少于 5
- `required key_points` 少于 3
- 缺少 `principle / stakeholder / citation / counterargument` 等类别
- 单国/对比题缺少 `cultural_context`
- 单国/对比题没有通过国家锚点校验
- `common_pitfalls` 不足或没有法域混淆型错误

### 4. 评分更苛刻
rubric 现在强调：
- `citation_accuracy`
- `cultural_contextualization`
- `jurisdictional_precision`
- `counterargument_handling`

并且增加了 **hard caps**：
- required key points 命中率不足时封顶
- 单国/对比题如果 citation / cultural / jurisdictional precision 太差，封顶
- 论证型题反方处理过弱，封顶

这意味着“写得像，但没真正答准”的答案更难拿高分。

## 默认评分权重

```text
final_answer_correctness    0.28
key_points_coverage         0.20
reasoning_quality           0.14
citation_accuracy           0.12
ethical_sensitivity         0.07
cultural_contextualization  0.08
jurisdictional_precision    0.06
counterargument_handling    0.05
```

## 默认通过阈值

- 选择题：`0.82`
- 开放题：`0.78`

## 用法

```bash
pip install -r requirements.txt
export POE_API_KEY=your_key_here

# 预估题量
python main.py estimate

# 构建 benchmark（推荐中英双语）
python main.py build --zh-en

# 作答与评分
python main.py answer --model GPT-5.4
python main.py grade  --model GPT-5.4
```

## 仍然建议你做的最后一步

这版已经把“结构性难度”大幅拉高了，但如果你要做论文级 benchmark，仍建议再抽样人工审 30–50 题，重点看：
- 是否还有模板化作文题漏网
- 是否真的需要法域精度才能答对
- 是否存在“看似难，其实用套话就能混过去”的题
- 是否能拉开 GPT-5.4 / Claude / 普通模型

## 主要改动文件

- `med_ethics_bench/config.py`
- `med_ethics_bench/prompts.py`
- `med_ethics_bench/question_generator.py`
- `med_ethics_bench/evaluator.py`
- `main.py`


## Stage 3-only 调试与恢复

如果前两阶段已经完成，且 `documents.jsonl` 已存在，可直接从第 3 阶段继续：

```bash
python main.py generate --output-dir ./data
```

如需同时生成中英文：

```bash
python main.py generate --output-dir ./data --zh-en
```

本版本还修复了 Poe `responses.create` 在部分兼容层下 `response.output_text` 为空、但正文实际位于 `output -> message -> content` 中时被误判为空字符串的问题。
